from django.urls import path
from .views import * 
# ดึงมาทุกฟังก์ชั่นใน views.py

urlpatterns = [
    path('', Home),
    path('api/all-todolist/',all_todolist), # localhost:8000/api/all-todolist
    path('api/create-todolist',post_todolist),  # create ไม่ต้องใส่ / ปิด
    path('api/update-todolist/<int:TID>',update_todolist),   # update ไม่ต้องใส่ / ปิด
    path('api/delete-todolist/<int:TID>',delete_todolist), 
]